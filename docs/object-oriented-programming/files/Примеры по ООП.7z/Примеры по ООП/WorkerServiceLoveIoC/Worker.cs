// ReSharper disable All

namespace WorkerServiceLoveIoC
{
    public class Worker : IHostedService
    {
        private readonly SshClient _sshClient;
        private readonly SftpClient _sftpClient;
        private readonly ILogger<Worker> _logger;

        public Worker(ILogger<Worker> logger, SshClient sshClient, SftpClient sftpClient)
        {
            _logger = logger;
            _sshClient = sshClient;
            _sftpClient = sftpClient;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("App start!!!");

            try
            {
                using (_sftpClient)
                {
                    _sftpClient.Connect();

                    bool exists = _sftpClient.Exists("/home/pi");

                    if (exists)
                    {
                        using (_sshClient)
                        {
                            _sshClient.Connect();

                            SshCommand command = _sshClient.RunCommand("ls");

                            _logger.LogInformation($"Command result: {command.Result}");

                            _sshClient.Disconnect();
                        }
                    }
                    else
                    {
                        _logger.LogInformation("Directory not exists!!!");
                    }

                    _sftpClient.Disconnect();
                }
            }
            catch (Exception error)
            {
                _logger.LogError(error, "Fatal error!!!");
            }

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("App stop!!!");

            return Task.CompletedTask;
        }
    }
}
