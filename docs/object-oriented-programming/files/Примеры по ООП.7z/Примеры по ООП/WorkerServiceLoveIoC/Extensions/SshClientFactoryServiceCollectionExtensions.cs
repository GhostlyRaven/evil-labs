﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Extensions
{
    public static class SshClientFactoryServiceCollectionExtensions
    {
        public static IDefaultSshClientBuilder AddSshClient(this IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            return services.AddSshClient(SshAndSftpHelper.DefaultClientName);
        }

        public static IDefaultSshClientBuilder AddSshClient(this IServiceCollection services, string name)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (name is null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            services.AddOptions();

            services.TryAddSingleton<ISshClientFactory, SshClientFactory>();

            return new DefaultSshClientBuilder(services, name);
        }

        public static IDefaultSshClientBuilder ConfigureSshClient(this IDefaultSshClientBuilder builder, Action<SshClientFactoryOptions> configureClient)
        {
            if (builder is null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            if (configureClient == null)
            {
                throw new ArgumentNullException(nameof(configureClient));
            }

            builder.Services.Configure(builder.Name, configureClient);

            return builder;
        }

        public static IDefaultSshClientBuilder ConfigureSshClient(this IDefaultSshClientBuilder builder, Action<IServiceProvider, SshClientFactoryOptions> configureClient)
        {
            if (builder is null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            if (configureClient == null)
            {
                throw new ArgumentNullException(nameof(configureClient));
            }

            builder.Services.AddTransient<IConfigureOptions<SshClientFactoryOptions>>(services =>
            {
                return new ConfigureNamedOptions<SshClientFactoryOptions>(builder.Name, options =>
                {
                    configureClient(services, options);
                });
            });

            return builder;
        }

        public static void RegisterDefaultSshClient(this IDefaultSshClientBuilder builder, ServiceLifetime lifetime = ServiceLifetime.Transient)
        {
            if (builder is null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            builder.Services.TryAdd(ServiceDescriptor.Describe(typeof(SshClient), serviceProvider =>
            {
                return serviceProvider.GetRequiredService<ISshClientFactory>()
                    .CreateClient(SshAndSftpHelper.DefaultClientName);
            }, lifetime));
        }

        public static SshClient CreateClient(this ISshClientFactory factory)
        {
            if (factory is null)
            {
                throw new ArgumentNullException(nameof(factory));
            }

            return factory.CreateClient(SshAndSftpHelper.DefaultClientName);
        }
    }
}
