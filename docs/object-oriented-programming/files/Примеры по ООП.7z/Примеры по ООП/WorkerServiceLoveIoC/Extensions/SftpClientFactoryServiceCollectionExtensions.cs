﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Extensions
{
    public static class SftpClientFactoryServiceCollectionExtensions
    {
        public static IDefaultSftpClientBuilder AddSftpClient(this IServiceCollection services)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            return services.AddSftpClient(SshAndSftpHelper.DefaultClientName);
        }

        public static IDefaultSftpClientBuilder AddSftpClient(this IServiceCollection services, string name)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (name is null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            services.AddOptions();

            services.TryAddSingleton<ISftpClientFactory, SftpClientFactory>();

            return new DefaultSftpClientBuilder(services, name);
        }

        public static IDefaultSftpClientBuilder ConfigureSftpClient(this IDefaultSftpClientBuilder builder, Action<SftpClientFactoryOptions> configureClient)
        {
            if (builder is null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            if (configureClient == null)
            {
                throw new ArgumentNullException(nameof(configureClient));
            }

            builder.Services.Configure(builder.Name, configureClient);

            return builder;
        }

        public static IDefaultSftpClientBuilder ConfigureSftpClient(this IDefaultSftpClientBuilder builder, Action<IServiceProvider, SftpClientFactoryOptions> configureClient)
        {
            if (builder is null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            if (configureClient == null)
            {
                throw new ArgumentNullException(nameof(configureClient));
            }

            builder.Services.AddTransient<IConfigureOptions<SftpClientFactoryOptions>>(services =>
            {
                return new ConfigureNamedOptions<SftpClientFactoryOptions>(builder.Name, options =>
                {
                    configureClient(services, options);
                });
            });

            return builder;
        }

        public static void RegisterDefaultSftpClient(this IDefaultSftpClientBuilder builder, ServiceLifetime lifetime = ServiceLifetime.Transient)
        {
            if (builder is null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            builder.Services.TryAdd(ServiceDescriptor.Describe(typeof(SftpClient), serviceProvider =>
            {
                return serviceProvider.GetRequiredService<ISftpClientFactory>()
                    .CreateClient(SshAndSftpHelper.DefaultClientName);
            }, lifetime));
        }

        public static SftpClient CreateClient(this ISftpClientFactory factory)
        {
            if (factory is null)
            {
                throw new ArgumentNullException(nameof(factory));
            }

            return factory.CreateClient(SshAndSftpHelper.DefaultClientName);
        }
    }
}
