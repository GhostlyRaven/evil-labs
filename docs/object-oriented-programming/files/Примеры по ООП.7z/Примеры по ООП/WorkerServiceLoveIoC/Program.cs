// ReSharper disable All

namespace WorkerServiceLoveIoC
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            IHost host = Host.CreateDefaultBuilder(args)
                .ConfigureServices((host, services) =>
                {
                    services.Configure<PasswordConnectionInfoOptions>(host.Configuration.GetSection(nameof(PasswordConnectionInfoOptions)));

                    services.AddSshClient()
                        .ConfigureSshClient((services, options) =>
                        {
                            PasswordConnectionInfoOptions optionsValue = services.GetRequiredService<IOptions<PasswordConnectionInfoOptions>>().Value;

                            options.ConnectionInfo = new PasswordConnectionInfo(optionsValue.Host, optionsValue.UserName, optionsValue.Password);
                        })
                        .RegisterDefaultSshClient(ServiceLifetime.Singleton);

                    services.AddSftpClient()
                        .ConfigureSftpClient((services, options) =>
                        {
                            PasswordConnectionInfoOptions optionsValue = services.GetRequiredService<IOptions<PasswordConnectionInfoOptions>>().Value;

                            options.ConnectionInfo = new PasswordConnectionInfo(optionsValue.Host, optionsValue.UserName, optionsValue.Password);
                        })
                        .RegisterDefaultSftpClient(ServiceLifetime.Singleton);

                    services.AddHostedService<Worker>();
                })
                .Build();

            host.Run();
        }
    }
}
