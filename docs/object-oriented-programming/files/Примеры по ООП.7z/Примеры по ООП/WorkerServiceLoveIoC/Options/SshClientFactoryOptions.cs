﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Options
{
    public sealed class SshClientFactoryOptions
    {
        public TimeSpan KeepAliveInterval { get; set; } = new TimeSpan(0, 0, 0, 0, -1);

        public ConnectionInfo? ConnectionInfo { get; set; }
    }
}
