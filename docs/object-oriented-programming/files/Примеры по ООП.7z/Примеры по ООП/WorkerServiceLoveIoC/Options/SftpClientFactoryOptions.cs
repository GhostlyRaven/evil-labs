﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Options
{
    public sealed class SftpClientFactoryOptions
    {
        public uint BufferSize { get; set; } = 32768U;

        public TimeSpan OperationTimeout { get; set; } = new TimeSpan(0, 0, 0, 0, -1);

        public TimeSpan KeepAliveInterval { get; set; } = new TimeSpan(0, 0, 0, 0, -1);

        public ConnectionInfo? ConnectionInfo { get; set; }
    }
}
