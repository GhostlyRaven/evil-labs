﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Options
{
    public sealed class PasswordConnectionInfoOptions
    {
        public string? Host { get; set; } = string.Empty;

        public string? UserName { get; set; } = string.Empty;

        public string? Password { get; set; } = string.Empty;
    }
}
