﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services
{
    public class DateTimeProvider : IDateTimeProvider
    {
        public DateTime DateTimeUtc { get; } = DateTime.UtcNow;

        public DateTime DateTimeLocal { get; } = DateTime.Now;

        public DateTimeOffset DateTimeOffsetUtc { get; } = DateTimeOffset.UtcNow;

        public DateTimeOffset DateTimeOffsetLocal { get; } = DateTimeOffset.Now;
    }
}
