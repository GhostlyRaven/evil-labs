﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services
{
    public interface IDateTimeProvider
    {
        DateTime DateTimeUtc { get; }

        DateTime DateTimeLocal { get; }

        DateTimeOffset DateTimeOffsetUtc { get; }

        DateTimeOffset DateTimeOffsetLocal { get; }
    }
}
