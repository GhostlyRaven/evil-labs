﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Implementations
{
    internal sealed class SftpClientFactory : ISftpClientFactory
    {
        private readonly IOptionsMonitor<SftpClientFactoryOptions> _optionsMonitor;

        public SftpClientFactory(IOptionsMonitor<SftpClientFactoryOptions> optionsMonitor)
        {
            _optionsMonitor = optionsMonitor;
        }

        public SftpClient CreateClient(string name)
        {
            if (name is null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            SftpClientFactoryOptions options = _optionsMonitor.Get(SshAndSftpHelper.NameWithSftpPrefix(name));

            return new SftpClient(options.ConnectionInfo)
            {
                KeepAliveInterval = options.KeepAliveInterval,
                OperationTimeout = options.OperationTimeout,
                BufferSize = options.BufferSize
            };
        }
    }
}
