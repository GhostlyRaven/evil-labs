﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Implementations
{
    internal sealed class SshClientFactory : ISshClientFactory
    {
        private readonly IOptionsMonitor<SshClientFactoryOptions> _optionsMonitor;

        public SshClientFactory(IOptionsMonitor<SshClientFactoryOptions> optionsMonitor)
        {
            _optionsMonitor = optionsMonitor;
        }

        public SshClient CreateClient(string name)
        {
            if (name is null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            SshClientFactoryOptions options = _optionsMonitor.Get(SshAndSftpHelper.NameWithSshPrefix(name));

            return new SshClient(options.ConnectionInfo)
            {
                KeepAliveInterval = options.KeepAliveInterval,
            };
        }
    }
}
