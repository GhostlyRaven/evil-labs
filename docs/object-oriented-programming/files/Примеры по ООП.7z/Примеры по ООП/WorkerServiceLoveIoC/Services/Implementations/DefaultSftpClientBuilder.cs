﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Implementations
{
    internal sealed class DefaultSftpClientBuilder : IDefaultSftpClientBuilder
    {
        public DefaultSftpClientBuilder(IServiceCollection services, string name)
        {
            Services = services;

            Name = SshAndSftpHelper.NameWithSftpPrefix(name);
        }

        public string Name { get; }

        public IServiceCollection Services { get; }
    }
}
