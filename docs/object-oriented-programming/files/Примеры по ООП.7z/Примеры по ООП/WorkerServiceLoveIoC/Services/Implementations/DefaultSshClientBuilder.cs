﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Implementations
{
    internal sealed class DefaultSshClientBuilder : IDefaultSshClientBuilder
    {
        public DefaultSshClientBuilder(IServiceCollection services, string name)
        {
            Services = services;

            Name = SshAndSftpHelper.NameWithSshPrefix(name);
        }

        public string Name { get; }

        public IServiceCollection Services { get; }
    }
}
