﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Interfaces
{
    public interface IDefaultSftpClientBuilder
    {
        string Name { get; }

        IServiceCollection Services { get; }
    }
}
