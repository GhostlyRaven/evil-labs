﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Interfaces
{
    public interface IDefaultSshClientBuilder
    {
        string Name { get; }

        IServiceCollection Services { get; }
    }
}
