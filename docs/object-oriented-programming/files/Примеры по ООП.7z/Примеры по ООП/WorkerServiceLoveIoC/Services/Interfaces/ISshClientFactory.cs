﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Interfaces
{
    public interface ISshClientFactory
    {
        SshClient CreateClient(string name);
    }
}
