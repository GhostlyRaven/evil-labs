﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services.Interfaces
{
    public interface ISftpClientFactory
    {
        SftpClient CreateClient(string name);
    }
}
