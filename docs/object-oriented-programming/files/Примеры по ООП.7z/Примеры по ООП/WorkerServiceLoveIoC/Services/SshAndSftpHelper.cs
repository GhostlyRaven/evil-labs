﻿// ReSharper disable All

namespace WorkerServiceLoveIoC.Services
{
    internal static class SshAndSftpHelper
    {
        public const string DefaultClientName = "Default";

        public static string NameWithSshPrefix(string name)
        {
            return $"SshClient.{name}";
        }

        public static string NameWithSftpPrefix(string name)
        {
            return $"SftpClient.{name}";
        }
    }
}
