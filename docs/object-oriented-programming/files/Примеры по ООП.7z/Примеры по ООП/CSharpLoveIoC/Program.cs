﻿using System;
using Microsoft.Extensions.DependencyInjection;

// ReSharper disable All

namespace CSharpLoveIoC
{
    public static class Program
    {
        public static void Main()
        {
            ServiceCollection services = new ServiceCollection();

            services.AddSingleton<IService1, Service1>();
            services.AddScoped<IService2, Service2>();
            services.AddTransient<IService3, Service3>();

            IServiceProvider provider = services.BuildServiceProvider();

            provider.GetRequiredService<IService1>().Do();
            provider.GetRequiredService<IService2>().Do();
            provider.GetRequiredService<IService3>().Do();

            Console.ReadKey();
        }
    }

    public interface IService1
    {
        void Do();
    }

    public class Service1 : IService1
    {
        public void Do()
        {
            Console.WriteLine(nameof(Service1));
        }
    }

    public interface IService2
    {
        void Do();
    }

    public class Service2 : IService2
    {
        public void Do()
        {
            Console.WriteLine(nameof(Service2));
        }
    }

    public interface IService3
    {
        void Do();
    }

    public class Service3 : IService3
    {
        public void Do()
        {
            Console.WriteLine(nameof(Service3));
        }
    }
}
