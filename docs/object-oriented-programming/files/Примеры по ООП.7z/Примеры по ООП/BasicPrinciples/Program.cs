﻿using System.Numerics;

namespace BasicPrinciples
{
    internal static class Program
    {
        internal static void Main()
        {
            Car<double> car1 = new Mercedes<double>();

            car1.CurrentWeight = 25;

            Console.WriteLine($"Current weight: {car1.CurrentWeight}. Speed coefficient: {car1.SpeedCoefficient}. Current speed: {car1.CurrentSpeed}.");

            Car<double> car2 = new Porsche<double>();

            car2.CurrentWeight = 55;

            Console.WriteLine($"Current weight: {car2.CurrentWeight}. Speed coefficient: {car2.SpeedCoefficient}. Current speed: {car2.CurrentSpeed}.");

            Console.WriteLine($"Multiply: {car1 * car2}");
            Console.WriteLine($"Division: {car1 / car2}");
            Console.WriteLine($"Addition: {car1 + car2}");
            Console.WriteLine($"Subtraction: {car1 - car2}");

            Console.WriteLine($"Map: {Map(512M, 0M, 1024M, 0M, 255M)}");

            Console.ReadKey();
        }

        private static T Map<T>(T value, T inMin, T inMax, T outMin, T outMax) where T : struct, INumber<T>
        {
            return (value - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
        }
    }

    internal interface ICar<T> where T : struct, INumber<T>
    {
        T CurrentSpeed { get; }

        T SpeedCoefficient { get; }

        T CurrentWeight { get; set; }
    }

    internal abstract class Car<T> : IMultiplyOperators<Car<T>, Car<T>, T>, IDivisionOperators<Car<T>, Car<T>, T>, IAdditionOperators<Car<T>, Car<T>, T>, ISubtractionOperators<Car<T>, Car<T>, T>, ICar<T> where T : struct, INumber<T>
    {
        public virtual T CurrentSpeed => T.Zero;

        public virtual T SpeedCoefficient => T.Zero;

        public virtual T CurrentWeight { get; set; } = T.Zero;

        public static T operator +(Car<T> left, Car<T> right)
        {
            return left.CurrentSpeed + right.CurrentSpeed;
        }

        public static T operator -(Car<T> left, Car<T> right)
        {
            return left.CurrentSpeed - right.CurrentSpeed;
        }

        public static T operator *(Car<T> left, Car<T> right)
        {
            return left.CurrentSpeed * right.CurrentSpeed;
        }

        public static T operator /(Car<T> left, Car<T> right)
        {
            return left.CurrentSpeed / right.CurrentSpeed;
        }
    }

#pragma warning disable CA2260
    internal class Mercedes<T> : Car<T> where T : struct, INumber<T>
#pragma warning restore CA2260 
    {
        public override T SpeedCoefficient => T.CreateChecked(10);

        public override T CurrentSpeed => SpeedCoefficient * CurrentWeight / T.CreateChecked(4);
    }

#pragma warning disable CA2260
    internal sealed class Porsche<T> : Car<T> where T : struct, INumber<T>
#pragma warning restore CA2260
    {
        public override T SpeedCoefficient => T.CreateChecked(22);

        public override T CurrentSpeed => SpeedCoefficient * CurrentWeight / T.CreateChecked(2);
    }
}
